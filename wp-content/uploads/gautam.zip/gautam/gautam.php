<?php 
// Plugin Name: Plugin Dec
echo 'hello everyone';